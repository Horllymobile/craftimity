export interface IApp {
  name: string;
  status: string;
  version: number;
  environment: string;
}
