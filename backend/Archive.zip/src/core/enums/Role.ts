export enum ERole {
  USER = "user",
  CRAFTMAN = "craftman",
  ADMIN = "admin",
  SUPER_ADMIN = "super_admin",
}
