export enum USERCHECKTYPE {
  EMAIL = "email",
  PHONE = "phone",
}
