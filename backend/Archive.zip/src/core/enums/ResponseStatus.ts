export enum EResponseStatus {
  SUCCESS = "success",
  FAILED = "failed",
  ERROR = "error",
}
