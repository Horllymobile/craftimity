export const jwtConstants = {
  secret:
    "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx4c2N5enRta2NrbG55YndweW1oIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTY5NDg1NTU4NiwiZXhwIjoyMDEwNDMxNTg2fQ",
};
