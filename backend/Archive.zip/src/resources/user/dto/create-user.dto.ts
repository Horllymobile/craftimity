// Craftimity_Password_Encryption
export class CreateUserDto {}
